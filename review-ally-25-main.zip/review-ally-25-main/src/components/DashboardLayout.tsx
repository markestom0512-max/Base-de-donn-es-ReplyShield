import { Link, useLocation, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Shield, LayoutDashboard, Star, Settings, BarChart3, CreditCard, LogOut, Rocket, Gift, Lock, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { title: "Vue d'ensemble", url: "/dashboard", icon: LayoutDashboard },
  { title: "Avis & Réponses", url: "/dashboard/reviews", icon: Star },
  { title: "Find Business", url: "/dashboard/find-business", icon: Search },
  { title: "Rapports", url: "/dashboard/reports", icon: BarChart3 },
  { title: "Paramètres", url: "/dashboard/settings", icon: Settings },
  { title: "Abonnement", url: "/dashboard/subscription", icon: CreditCard },
  { title: "Growth", url: "/dashboard/growth", icon: Rocket },
  { title: "Parrainage", url: "/dashboard/referral", icon: Gift },
];

function DashboardSidebar() {
  const location = useLocation();
  const { signOut, subscription } = useAuth();
  const navigate = useNavigate();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const hasGrowthAccess = subscription.plan === "pro" || subscription.plan === "agency";

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarContent className="flex flex-col h-full">
        <div className="p-4">
          <Link to="/dashboard" className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary shrink-0" />
            {!collapsed && <span className="font-heading font-bold text-lg">ReplyShield</span>}
          </Link>
        </div>
        <SidebarGroup className="flex-1">
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild>
                    <Link
                      to={item.url}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                        item.url === "/dashboard/growth" && !hasGrowthAccess
                          ? "text-muted-foreground/40 cursor-default"
                          : location.pathname === item.url
                            ? "bg-primary/10 text-primary font-medium"
                            : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                      }`}
                    >
                      <item.icon className="w-4 h-4 shrink-0" />
                      {!collapsed && (
                        <span className="flex items-center gap-2">
                          {item.title}
                          {item.url === "/dashboard/growth" && !hasGrowthAccess && <Lock className="w-3 h-3" />}
                        </span>
                      )}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <div className="p-4">
          <Button variant="ghost" size="sm" onClick={handleSignOut} className="w-full justify-start text-muted-foreground">
            <LogOut className="w-4 h-4 mr-2 shrink-0" />
            {!collapsed && "Déconnexion"}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}

export default function DashboardLayout() {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <DashboardSidebar />
        <div className="flex-1 flex flex-col">
          <header className="h-14 flex items-center border-b border-border/30 px-4">
            <SidebarTrigger />
          </header>
          <main className="flex-1 p-6 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

import { motion } from "framer-motion";
import { Sparkles, Star, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const fakeReview = {
  author: "Marie L.",
  rating: 2,
  text: "Service décevant, j'ai attendu 45 minutes pour être servie et le plat était froid. Le serveur n'a même pas présenté d'excuses.",
};

export default function DemoWidget() {
  const [generating, setGenerating] = useState(false);
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);

  const generate = async () => {
    setGenerating(true);
    setDisplayed("");
    setDone(false);

    try {
      const { data, error } = await supabase.functions.invoke("generate-reply", {
        body: {
          reviewText: fakeReview.text,
          rating: fakeReview.rating,
          sector: "restaurant",
          tone: "professionnel, empathique",
        },
      });

      if (error) throw error;
      const fullText = data?.reply || "Réponse non disponible";

      // Typewriter effect
      let i = 0;
      const interval = setInterval(() => {
        i++;
        setDisplayed(fullText.slice(0, i));
        if (i >= fullText.length) {
          clearInterval(interval);
          setGenerating(false);
          setDone(true);
        }
      }, 20);
    } catch (err) {
      console.error(err);
      // Fallback to mock response
      const fallback = `Bonjour Marie, merci d'avoir pris le temps de partager votre expérience. Nous sommes sincèrement navrés pour cette attente et ce désagrément. Ce n'est pas du tout le niveau de service que nous souhaitons offrir. Nous aimerions beaucoup en discuter avec vous — n'hésitez pas à nous contacter directement pour que nous puissions rectifier cela.`;
      let i = 0;
      const interval = setInterval(() => {
        i++;
        setDisplayed(fallback.slice(0, i));
        if (i >= fallback.length) {
          clearInterval(interval);
          setGenerating(false);
          setDone(true);
        }
      }, 20);
    }
  };

  return (
    <section className="py-24 px-4">
      <div className="container max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Voyez l'IA en action
          </h2>
          <p className="text-muted-foreground">
            Un avis négatif ? ReplyShield génère la réponse parfaite.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-card p-6 md:p-8"
        >
          {/* Review */}
          <div className="flex items-start gap-4 mb-6">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center shrink-0">
              <User className="w-5 h-5 text-muted-foreground" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm">{fakeReview.author}</span>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${i < fakeReview.rating ? "fill-star text-star" : "text-muted-foreground/30"}`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{fakeReview.text}</p>
            </div>
          </div>

          {/* Generate button */}
          {!generating && !done && (
            <Button onClick={generate} variant="hero" className="w-full mb-6">
              <Sparkles className="w-4 h-4 mr-2" />
              Générer la réponse IA
            </Button>
          )}

          {/* Response */}
          {(generating || done) && (
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-5 mt-4">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-primary" />
                <span className="text-xs font-medium text-primary">Réponse générée par ReplyShield</span>
              </div>
              <p className="text-sm leading-relaxed">
                {displayed}
                {generating && <span className="inline-block w-0.5 h-4 bg-primary animate-pulse ml-0.5 align-middle" />}
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

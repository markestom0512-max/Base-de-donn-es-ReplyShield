import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Est-ce que les réponses générées sonnent naturelles ?",
    a: "Absolument. Notre IA est entraînée pour produire des réponses humaines, personnalisées et adaptées au ton de votre entreprise. Vos clients ne verront aucune différence.",
  },
  {
    q: "Puis-je relire et modifier avant publication ?",
    a: "Oui ! Le mode validation manuelle vous permet de relire, modifier ou régénérer chaque réponse avant qu'elle ne soit publiée. Vous gardez toujours le contrôle.",
  },
  {
    q: "Est-ce compatible avec tous les secteurs d'activité ?",
    a: "ReplyShield fonctionne pour tous les secteurs : restauration, hôtellerie, santé, commerce, services, artisanat… L'IA s'adapte au vocabulaire de votre industrie.",
  },
  {
    q: "Que se passe-t-il si je reçois un avis négatif grave ?",
    a: "Les avis avec un score de 1 étoile ou contenant des sujets sensibles sont automatiquement flaggés pour validation manuelle, même en mode auto-publication.",
  },
  {
    q: "Mon compte Google Business est-il en sécurité ?",
    a: "Nous utilisons l'authentification OAuth2 officielle de Google. Nous n'avons jamais accès à votre mot de passe et vous pouvez révoquer l'accès à tout moment.",
  },
  {
    q: "Puis-je annuler mon abonnement à tout moment ?",
    a: "Oui, sans engagement. Vous pouvez annuler depuis votre tableau de bord en un clic. Vos données restent accessibles pendant 30 jours après l'annulation.",
  },
];

export default function FAQ() {
  return (
    <section className="py-24 px-4" id="faq">
      <div className="container max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Questions fréquentes
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="glass-card px-6 border-none"
              >
                <AccordionTrigger className="text-left text-sm font-medium hover:no-underline">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}

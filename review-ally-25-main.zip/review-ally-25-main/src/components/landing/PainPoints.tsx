import { motion } from "framer-motion";
import { Clock, Frown, TrendingDown } from "lucide-react";

const points = [
  {
    icon: Clock,
    title: "« Je n'ai pas le temps »",
    description: "73% des entreprises ne répondent jamais à leurs avis par manque de temps.",
  },
  {
    icon: Frown,
    title: "« Je ne sais pas quoi répondre »",
    description: "Surtout aux avis négatifs, rater la réponse peut aggraver la situation.",
  },
  {
    icon: TrendingDown,
    title: "« Ça impacte mon SEO local »",
    description: "Google favorise les entreprises qui répondent à leurs avis dans son algorithme local.",
  },
];

export default function PainPoints() {
  return (
    <section className="py-24 px-4">
      <div className="container max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Le problème que vous connaissez
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Chaque avis sans réponse est une opportunité perdue.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {points.map((point, i) => (
            <motion.div
              key={point.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
              className="glass-card p-8 text-center group hover:border-primary/30 transition-colors"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-5 group-hover:bg-primary/20 transition-colors">
                <point.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-semibold mb-3">{point.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{point.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

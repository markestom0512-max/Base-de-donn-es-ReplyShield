import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    quote: "En 2 mois, mes avis sans réponse sont passés de 47 à 0. Et mon classement Google a bondi.",
    name: "Marc T.",
    role: "Gérant, Brasserie Le Comptoir",
    initials: "MT",
  },
  {
    quote: "J'avais peur que ça sonne robotique. Mais mes clients me disent que mes réponses sont parfaites.",
    name: "Sophie L.",
    role: "Propriétaire, Institut Beauté Lumière",
    initials: "SL",
  },
  {
    quote: "Je gère 5 établissements. ReplyShield m'économise 3 heures par semaine.",
    name: "Kevin B.",
    role: "Directeur, Groupe Hôtelier Azur",
    initials: "KB",
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 px-4">
      <div className="container max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Ce qu'en disent nos clients
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="glass-card p-8"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-star text-star" />
                ))}
              </div>
              <p className="text-sm leading-relaxed mb-6 italic text-muted-foreground">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                  {t.initials}
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

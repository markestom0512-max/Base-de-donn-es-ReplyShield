import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Shield, MessageCircle, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const logos = [
  "Boulangerie Martin",
  "Garage Dupont Auto",
  "Cabinet Dr. Lefebvre",
  "Salon Élégance",
  "Pizzeria Bella",
];

function AnimatedCounter({ target }: { target: number }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [target]);
  return <span>{count.toLocaleString("fr-FR")}</span>;
}

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-4 pt-20">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container max-w-5xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Propulsé par l'IA</span>
          </div>

          <h1 className="font-heading text-4xl sm:text-5xl md:text-7xl font-extrabold tracking-tight leading-tight mb-6">
            Répondez à tous vos avis Google.{" "}
            <span className="gradient-text">Automatiquement.</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            ReplyShield génère des réponses personnalisées à vos avis positifs ET négatifs en quelques secondes.
            Boostez votre référencement local sans lever le petit doigt.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button variant="hero" size="lg" className="h-14 px-8 text-base" asChild>
              <Link to="/signup">
                Essayer gratuitement 14 jours
                <ArrowRight className="w-5 h-5 ml-1" />
              </Link>
            </Button>
            <Button variant="heroOutline" size="lg" className="h-14 px-8">
              <MessageCircle className="w-5 h-5 mr-1" />
              Voir une démo
            </Button>
          </div>

          {/* Social proof counter */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mb-12"
          >
            <p className="text-3xl md:text-4xl font-heading font-bold text-primary">
              +<AnimatedCounter target={2847} />
            </p>
            <p className="text-sm text-muted-foreground mt-1">avis répondus cette semaine</p>
          </motion.div>
        </motion.div>

        {/* Logos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="border-t border-border/30 pt-8"
        >
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-6">Ils nous font confiance</p>
          <div className="flex flex-wrap items-center justify-center gap-8">
            {logos.map((name) => (
              <span key={name} className="text-sm font-medium text-muted-foreground/60 font-heading">
                {name}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

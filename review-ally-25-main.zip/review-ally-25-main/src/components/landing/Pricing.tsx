import { motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const plans = [
  {
    name: "Solo",
    price: "9",
    slug: "solo",
    popular: false,
    features: [
      { text: "1 établissement", included: true },
      { text: "50 réponses / mois", included: true },
      { text: "Validation manuelle", included: true },
      { text: "Rapport mensuel", included: true },
      { text: "Support email", included: true },
      { text: "Auto-publication", included: false },
    ],
  },
  {
    name: "Pro",
    price: "25",
    slug: "pro",
    popular: true,
    features: [
      { text: "3 établissements", included: true },
      { text: "Réponses illimitées", included: true },
      { text: "Validation optionnelle", included: true },
      { text: "Rapport mensuel", included: true },
      { text: "Support prioritaire", included: true },
      { text: "Auto-publication", included: true },
    ],
  },
  {
    name: "Agence",
    price: "149",
    slug: "agency",
    popular: false,
    features: [
      { text: "15 établissements", included: true },
      { text: "Réponses illimitées", included: true },
      { text: "Validation optionnelle", included: true },
      { text: "Rapport mensuel", included: true },
      { text: "Support dédié", included: true },
      { text: "Auto-publication", included: true },
    ],
  },
];

export default function Pricing() {
  return (
    <section className="py-24 px-4" id="pricing">
      <div className="container max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Des tarifs simples et transparents
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            14 jours d'essai gratuit. Sans carte bancaire. Annulez à tout moment.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className={`glass-card p-8 relative flex flex-col ${
                plan.popular ? "border-primary/50 ring-1 ring-primary/20" : ""
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-semibold px-4 py-1 rounded-full">
                  Le plus populaire
                </span>
              )}
              <div className="text-center mb-8">
                <h3 className="font-heading text-xl font-bold mb-2">{plan.name}</h3>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-heading font-extrabold">{plan.price}€</span>
                  <span className="text-muted-foreground text-sm">/mois</span>
                </div>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((f) => (
                  <li key={f.text} className="flex items-center gap-3 text-sm">
                    {f.included ? (
                      <Check className="w-4 h-4 text-primary shrink-0" />
                    ) : (
                      <X className="w-4 h-4 text-muted-foreground/40 shrink-0" />
                    )}
                    <span className={f.included ? "" : "text-muted-foreground/50"}>{f.text}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={plan.popular ? "hero" : "heroOutline"}
                className="w-full"
                asChild
              >
                <Link to={`/signup?plan=${plan.slug}`}>Commencer</Link>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

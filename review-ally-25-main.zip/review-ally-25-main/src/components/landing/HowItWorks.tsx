import { motion } from "framer-motion";
import { Link2, Brain, Send } from "lucide-react";

const steps = [
  {
    icon: Link2,
    step: "01",
    title: "Connectez votre Google Business",
    description: "Autorisation en 1 clic, sécurisé OAuth2. Vos données restent les vôtres.",
  },
  {
    icon: Brain,
    step: "02",
    title: "L'IA analyse chaque avis",
    description: "Détection du sentiment, du contexte et du ton approprié pour chaque réponse.",
  },
  {
    icon: Send,
    step: "03",
    title: "La réponse est publiée",
    description: "Personnalisée dans le ton de votre marque. Automatiquement ou après validation.",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-24 px-4">
      <div className="container max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
            Comment ça marche
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Trois étapes pour ne plus jamais laisser un avis sans réponse.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-px bg-border/50 -translate-y-1/2" />

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.5 }}
                className="relative text-center"
              >
                <div className="glass-card p-8 relative z-10">
                  <span className="text-xs font-mono text-primary mb-4 block">{step.step}</span>
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-5">
                    <step.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-heading text-lg font-semibold mb-3">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export const PLANS = {
  solo: {
    slug: "solo",
    name: "Solo",
    price: "9€",
    product_id: "prod_U5PccRdnI1Nhkv",
    price_id: "price_1T7EnDLDD04eO00h1sSQFtnB",
    features: ["1 établissement", "50 réponses/mois", "Support email"],
  },
  pro: {
    slug: "pro",
    name: "Pro",
    price: "25€",
    product_id: "prod_U5PcUG3He1yqeD",
    price_id: "price_1T7EnTLDD04eO00hIiefGT4u",
    features: ["3 établissements", "Réponses illimitées", "Support prioritaire", "Auto-publication"],
  },
  agency: {
    slug: "agency",
    name: "Agence",
    price: "149€",
    product_id: "prod_U5PdAgmWqv0sXG",
    price_id: "price_1T7EnoLDD04eO00hMzZO7A8t",
    features: ["15 établissements", "Réponses illimitées", "Support dédié", "Auto-publication"],
  },
} as const;

export type PlanSlug = keyof typeof PLANS;

export function getPlanByProductId(productId: string): PlanSlug | null {
  for (const [slug, plan] of Object.entries(PLANS)) {
    if (plan.product_id === productId) return slug as PlanSlug;
  }
  return null;
}

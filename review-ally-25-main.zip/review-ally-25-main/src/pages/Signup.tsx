import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const sectors = [
  { value: "restaurant", label: "Restaurant" },
  { value: "hotel", label: "Hôtel" },
  { value: "commerce", label: "Commerce" },
  { value: "sante", label: "Santé" },
  { value: "services", label: "Services" },
  { value: "autre", label: "Autre" },
];

export default function Signup() {
  const [searchParams] = useSearchParams();
  const plan = searchParams.get("plan") || "pro";
  const refCode = searchParams.get("ref");
  const [form, setForm] = useState({ fullName: "", email: "", password: "", businessName: "", sector: "" });
  const [agreed, setAgreed] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const passwordStrength = () => {
    const p = form.password;
    if (p.length < 6) return { label: "Faible", color: "bg-destructive", width: "w-1/4" };
    if (p.length < 10) return { label: "Moyen", color: "bg-accent", width: "w-2/4" };
    if (/[A-Z]/.test(p) && /[0-9]/.test(p) && p.length >= 10) return { label: "Fort", color: "bg-primary", width: "w-full" };
    return { label: "Bon", color: "bg-primary/70", width: "w-3/4" };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) { toast.error("Veuillez accepter les CGU"); return; }
    setLoading(true);
    try {
      // Pass all metadata so the handle_new_user trigger can create profile, subscription & establishment
      await signUp(form.email, form.password, {
        full_name: form.fullName,
        business_name: form.businessName,
        sector: form.sector,
        plan: plan,
      });

      // Track referral if ref code present (needs a session, so best-effort)
      try {
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (currentUser && refCode) {
          const { data: referrer } = await supabase.from("profiles").select("id").eq("referral_code", refCode).single();
          if (referrer) {
            await supabase.from("referrals").insert({
              referrer_id: referrer.id,
              referred_id: currentUser.id,
            });
          }
        }
      } catch { /* no session yet if email confirmation is required */ }

      toast.success("Vérifiez votre email pour confirmer votre compte !");
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de l'inscription");
    } finally {
      setLoading(false);
    }
  };

  const strength = passwordStrength();

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-background">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Shield className="w-8 h-8 text-primary" />
            <span className="font-heading text-2xl font-bold">ReplyShield</span>
          </Link>
          <h1 className="font-heading text-2xl font-bold mb-2">Créer votre compte</h1>
          <p className="text-sm text-muted-foreground">14 jours d'essai gratuit — sans carte bancaire</p>
        </div>

        <form onSubmit={handleSubmit} className="glass-card p-8 space-y-4">
          <div className="space-y-2">
            <Label>Nom complet</Label>
            <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="Jean Dupont" required />
          </div>

          <div className="space-y-2">
            <Label>Email professionnel</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="vous@entreprise.com" required />
          </div>

          <div className="space-y-2">
            <Label>Mot de passe</Label>
            <div className="relative">
              <Input type={showPassword ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" required minLength={6} />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {form.password && (
              <div className="space-y-1">
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div className={`h-full ${strength.color} ${strength.width} transition-all rounded-full`} />
                </div>
                <p className="text-xs text-muted-foreground">{strength.label}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Nom de l'entreprise</Label>
            <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} placeholder="Ma Super Entreprise" required />
          </div>

          <div className="space-y-2">
            <Label>Secteur d'activité</Label>
            <Select value={form.sector} onValueChange={(v) => setForm({ ...form, sector: v })}>
              <SelectTrigger><SelectValue placeholder="Choisir un secteur" /></SelectTrigger>
              <SelectContent>
                {sectors.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <Checkbox id="cgu" checked={agreed} onCheckedChange={(v) => setAgreed(v === true)} />
            <label htmlFor="cgu" className="text-xs text-muted-foreground">
              J'accepte les <a href="#" className="text-primary hover:underline">Conditions Générales d'Utilisation</a>
            </label>
          </div>

          <Button type="submit" variant="hero" className="w-full" disabled={loading || !agreed}>
            {loading ? "Création..." : "Créer mon compte gratuitement"}
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Déjà un compte ?{" "}
          <Link to="/login" className="text-primary hover:underline font-medium">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Shield, ArrowRight, Link2, Palette, Check, RefreshCw } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const plans = [
  { slug: "solo", name: "Solo", price: "9€/mois", desc: "1 établissement, 50 réponses" },
  { slug: "pro", name: "Pro", price: "25€/mois", desc: "3 établissements, illimité" },
  { slug: "agency", name: "Agence", price: "149€/mois", desc: "15 établissements, illimité" },
];

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [selectedPlan, setSelectedPlan] = useState("pro");
  const [toneFormal, setToneFormal] = useState(50);
  const [toneLength, setToneLength] = useState(50);
  const [keywords, setKeywords] = useState("");
  const [avoid, setAvoid] = useState("");
  const [placeId, setPlaceId] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [syncDone, setSyncDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const finish = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await supabase.from("profiles").update({
        tone_formal: toneFormal,
        tone_length: toneLength,
        keywords_include: keywords.split(",").map((k) => k.trim()).filter(Boolean),
        keywords_avoid: avoid.split(",").map((k) => k.trim()).filter(Boolean),
        onboarding_completed: true,
      }).eq("id", user.id);

      // Update plan - upsert in case subscription row is missing
      const { data: existingSub } = await supabase.from("subscriptions").select("id").eq("user_id", user.id).maybeSingle();
      if (existingSub) {
        await supabase.from("subscriptions").update({ plan: selectedPlan }).eq("id", existingSub.id);
      } else {
        await supabase.from("subscriptions").insert({
          user_id: user.id,
          plan: selectedPlan,
          status: "trialing",
          trial_ends_at: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      toast.success("Configuration terminée !");
      navigate("/dashboard");
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-background">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <Shield className="w-8 h-8 text-primary mx-auto mb-4" />
          <h1 className="font-heading text-2xl font-bold mb-2">Configurons votre compte</h1>
          <div className="flex items-center justify-center gap-2 mt-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`h-2 rounded-full transition-all ${s === step ? "w-8 bg-primary" : s < step ? "w-8 bg-primary/50" : "w-8 bg-secondary"}`} />
            ))}
          </div>
        </div>

        <div className="glass-card p-8">
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="font-heading text-lg font-bold mb-1">Choisissez votre plan</h2>
                <p className="text-sm text-muted-foreground">14 jours d'essai gratuit pour tous les plans</p>
              </div>
              <div className="space-y-3">
                {plans.map((p) => (
                  <button
                    key={p.slug}
                    onClick={() => setSelectedPlan(p.slug)}
                    className={`w-full p-4 rounded-lg border text-left transition-all flex items-center justify-between ${
                      selectedPlan === p.slug ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-sm">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.desc}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-heading font-bold">{p.price}</span>
                      {selectedPlan === p.slug && <Check className="w-4 h-4 text-primary" />}
                    </div>
                  </button>
                ))}
              </div>
              <Button variant="hero" className="w-full" onClick={() => setStep(2)}>
                Continuer <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <Link2 className="w-10 h-10 text-primary mx-auto mb-3" />
                <h2 className="font-heading text-lg font-bold mb-1">Connectez Google Business</h2>
                <p className="text-sm text-muted-foreground">Entrez votre Google Place ID pour importer vos avis</p>
              </div>
              <div className="space-y-3">
                <div>
                  <Label className="text-xs">Google Place ID</Label>
                  <Input
                    value={placeId}
                    onChange={(e) => setPlaceId(e.target.value)}
                    placeholder="ChIJ..."
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Trouvez-le sur{" "}
                    <a href="https://developers.google.com/maps/documentation/places/web-service/place-id-finder" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      Google Place ID Finder
                    </a>
                  </p>
                </div>
                {placeId && (
                  <Button
                    variant="hero"
                    className="w-full"
                    disabled={syncing || syncDone}
                    onClick={async () => {
                      setSyncing(true);
                      try {
                        const { data: establishments } = await supabase
                          .from("establishments").select("id").eq("user_id", user!.id).limit(1).single();
                        if (!establishments) throw new Error("Aucun établissement trouvé");
                        await supabase.from("establishments").update({ google_place_id: placeId }).eq("id", establishments.id);
                        const { data, error } = await supabase.functions.invoke("sync-google-reviews", {
                          body: { establishmentId: establishments.id },
                        });
                        if (error) throw error;
                        if (data?.error) throw new Error(data.error);
                        toast.success(data.message || "Avis importés !");
                        setSyncDone(true);
                      } catch (err: any) {
                        toast.error(err.message || "Erreur de synchronisation");
                      } finally {
                        setSyncing(false);
                      }
                    }}
                  >
                    {syncing ? <RefreshCw className="w-4 h-4 mr-1 animate-spin" /> : syncDone ? <Check className="w-4 h-4 mr-1" /> : <Link2 className="w-4 h-4 mr-1" />}
                    {syncing ? "Import en cours..." : syncDone ? "Avis importés !" : "Importer mes avis"}
                  </Button>
                )}
              </div>
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(1)} className="flex-1">Retour</Button>
                <Button variant="hero" onClick={() => setStep(3)} className="flex-1">
                  {placeId ? "Continuer" : "Passer pour l'instant"} <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <Palette className="w-10 h-10 text-primary mx-auto mb-3" />
                <h2 className="font-heading text-lg font-bold mb-1">Ton de votre marque</h2>
                <p className="text-sm text-muted-foreground">Personnalisez le style des réponses IA</p>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-muted-foreground mb-2">
                    <span>Décontracté</span>
                    <span>Formel</span>
                  </div>
                  <Slider value={[toneFormal]} onValueChange={(v) => setToneFormal(v[0])} max={100} step={1} />
                </div>
                <div>
                  <div className="flex justify-between text-xs text-muted-foreground mb-2">
                    <span>Court</span>
                    <span>Détaillé</span>
                  </div>
                  <Slider value={[toneLength]} onValueChange={(v) => setToneLength(v[0])} max={100} step={1} />
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label className="text-xs">Mots-clés à toujours inclure</Label>
                  <Input value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="merci, à bientôt, équipe" />
                </div>
                <div>
                  <Label className="text-xs">Phrases à éviter</Label>
                  <Input value={avoid} onChange={(e) => setAvoid(e.target.value)} placeholder="désolé pour le dérangement" />
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(2)} className="flex-1">Retour</Button>
                <Button variant="hero" onClick={finish} className="flex-1" disabled={loading}>
                  {loading ? "Sauvegarde..." : "Terminer"} <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

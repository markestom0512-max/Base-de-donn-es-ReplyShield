import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Star, MessageSquare, TrendingUp, Clock } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function DashboardOverview() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ reviews: 0, responseRate: 0, avgRating: 0, pending: 0 });
  const [recentReviews, setRecentReviews] = useState<any[]>([]);
  const [allReviews, setAllReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    try {
      const { data: establishments } = await supabase.from("establishments").select("id").eq("user_id", user!.id);
      if (!establishments?.length) { setLoading(false); return; }
      const estIds = establishments.map((e) => e.id);

      const { data: reviews } = await supabase.from("reviews").select("*, replies(*)").in("establishment_id", estIds).order("created_at", { ascending: false });

      if (reviews) {
        const totalReviews = reviews.length;
        const replied = reviews.filter((r) => r.replies && r.replies.length > 0).length;
        const pending = reviews.filter((r) => !r.replies || r.replies.length === 0 || r.replies.some((rep: any) => rep.status === "pending")).length;
        const avgRating = totalReviews ? reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews : 0;

        setStats({
          reviews: totalReviews,
          responseRate: totalReviews ? Math.round((replied / totalReviews) * 100) : 0,
          avgRating: Math.round(avgRating * 10) / 10,
          pending,
        });
        setRecentReviews(reviews.slice(0, 5));
        setAllReviews(reviews);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Build chart data from real reviews grouped by month (last 6 months)
  const chartData = useMemo(() => {
    const months: { month: string; avis: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("fr-FR", { month: "short" });
      const count = allReviews.filter((r) => {
        const rd = new Date(r.created_at);
        return rd.getFullYear() === d.getFullYear() && rd.getMonth() === d.getMonth();
      }).length;
      months.push({ month: label.charAt(0).toUpperCase() + label.slice(1), avis: count });
    }
    return months;
  }, [allReviews]);

  const statCards = [
    { label: "Avis ce mois", value: stats.reviews, icon: MessageSquare, change: "+12%" },
    { label: "Taux de réponse", value: `${stats.responseRate}%`, icon: TrendingUp, change: stats.responseRate === 100 ? "✅" : "" },
    { label: "Note moyenne", value: `${stats.avgRating} ⭐`, icon: Star, change: "" },
    { label: "En attente", value: stats.pending, icon: Clock, change: "", action: true },
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="font-heading text-2xl font-bold">Vue d'ensemble</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl">
      <h1 className="font-heading text-2xl font-bold">Vue d'ensemble</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <div key={card.label} className="glass-card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted-foreground">{card.label}</span>
              <card.icon className="w-4 h-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-heading font-bold">{card.value}</p>
            {card.change && <span className="text-xs text-primary">{card.change}</span>}
            {card.action && stats.pending > 0 && (
              <Button variant="hero" size="sm" className="mt-2 w-full text-xs" asChild>
                <Link to="/dashboard/reviews">Traiter maintenant</Link>
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Chart */}
      <div className="glass-card p-6">
        <h3 className="font-heading font-semibold mb-4">Évolution des avis (6 mois)</h3>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorAvis" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 22%)" />
            <XAxis dataKey="month" stroke="hsl(215, 20%, 65%)" fontSize={12} />
            <YAxis stroke="hsl(215, 20%, 65%)" fontSize={12} />
            <Tooltip contentStyle={{ backgroundColor: "hsl(222, 47%, 14%)", border: "1px solid hsl(217, 33%, 22%)", borderRadius: "8px", color: "hsl(210, 40%, 98%)" }} />
            <Area type="monotone" dataKey="avis" stroke="hsl(142, 71%, 45%)" fillOpacity={1} fill="url(#colorAvis)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Recent activity */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold">Activité récente</h3>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/dashboard/reviews">Voir tout</Link>
          </Button>
        </div>
        {recentReviews.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Aucun avis pour le moment. Simulez un avis depuis la page Avis & Réponses !</p>
        ) : (
          <div className="space-y-3">
            {recentReviews.map((review) => (
              <div key={review.id} className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30">
                <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                  {review.author_name?.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-medium">{review.author_name}</span>
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < review.rating ? "fill-star text-star" : "text-muted-foreground/30"}`} />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{review.text}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full shrink-0 ${
                  review.replies?.some((r: any) => r.status === "published")
                    ? "bg-primary/20 text-primary"
                    : "bg-accent/20 text-accent"
                }`}>
                  {review.replies?.some((r: any) => r.status === "published") ? "✅ Répondu" : "⏳ En attente"}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

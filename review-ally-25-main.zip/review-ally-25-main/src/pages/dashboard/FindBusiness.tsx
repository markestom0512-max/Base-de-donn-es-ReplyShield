import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Star, ExternalLink, ChevronDown, ChevronUp, Loader2, Link2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

interface Place {
  id: string;
  displayName?: { text: string };
  formattedAddress?: string;
  rating?: number;
  userRatingCount?: number;
  types?: string[];
  googleMapsUri?: string;
}

interface Review {
  name: string;
  rating: number;
  text?: { text: string };
  authorAttribution?: { displayName: string; photoUri?: string };
  relativePublishTimeDescription?: string;
  publishTime?: string;
}

interface PlaceDetail {
  id: string;
  displayName?: { text: string };
  formattedAddress?: string;
  rating?: number;
  userRatingCount?: number;
  reviews?: Review[];
  websiteUri?: string;
  googleMapsUri?: string;
}

export default function FindBusiness() {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [places, setPlaces] = useState<Place[]>([]);
  const [searching, setSearching] = useState(false);
  const [expandedPlace, setExpandedPlace] = useState<string | null>(null);
  const [placeDetails, setPlaceDetails] = useState<Record<string, PlaceDetail>>({});
  const [loadingDetail, setLoadingDetail] = useState<string | null>(null);
  const [linking, setLinking] = useState<string | null>(null);
  const [linkedPlaceId, setLinkedPlaceId] = useState<string | null>(null);

  const linkBusiness = async (place: Place) => {
    if (!user) return;
    setLinking(place.id);
    try {
      // Check if user has an establishment
      const { data: existing } = await supabase
        .from("establishments")
        .select("id")
        .eq("user_id", user.id)
        .limit(1)
        .single();

      if (existing) {
        // Update existing establishment with this place ID
        await supabase.from("establishments").update({
          google_place_id: place.id,
          name: place.displayName?.text || "Mon établissement",
          address: place.formattedAddress || null,
        }).eq("id", existing.id);
      } else {
        // Create new establishment
        await supabase.from("establishments").insert({
          user_id: user.id,
          google_place_id: place.id,
          name: place.displayName?.text || "Mon établissement",
          address: place.formattedAddress || null,
        });
      }

      // Sync reviews
      const { data: est } = await supabase
        .from("establishments")
        .select("id")
        .eq("user_id", user.id)
        .limit(1)
        .single();

      if (est) {
        await supabase.functions.invoke("sync-google-reviews", {
          body: { establishmentId: est.id },
        });
      }

      setLinkedPlaceId(place.id);
      toast.success("Établissement lié et avis synchronisés !");
    } catch (err: any) {
      toast.error(err.message || "Erreur lors de la liaison");
    } finally {
      setLinking(null);
    }
  };

  const searchPlaces = async () => {
    if (query.trim().length < 2) {
      toast.error("Entrez au moins 2 caractères");
      return;
    }
    setSearching(true);
    setExpandedPlace(null);
    try {
      const { data, error } = await supabase.functions.invoke("search-places", {
        body: { query },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setPlaces(data.places || []);
      if (!data.places?.length) toast.info("Aucun résultat trouvé");
    } catch (err: any) {
      toast.error(err.message || "Erreur de recherche");
    } finally {
      setSearching(false);
    }
  };

  const toggleDetails = async (placeId: string) => {
    if (expandedPlace === placeId) {
      setExpandedPlace(null);
      return;
    }
    setExpandedPlace(placeId);

    if (placeDetails[placeId]) return;

    setLoadingDetail(placeId);
    try {
      const { data, error } = await supabase.functions.invoke("search-places", {
        body: { placeId },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      if (data.place) {
        setPlaceDetails((prev) => ({ ...prev, [placeId]: data.place }));
      }
    } catch (err: any) {
      toast.error(err.message || "Impossible de charger les avis");
      setExpandedPlace(null);
    } finally {
      setLoadingDetail(null);
    }
  };

  const renderStars = (rating: number) => (
    <div className="flex gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-3.5 h-3.5 ${
            i < Math.round(rating) ? "fill-star text-star" : "text-muted-foreground/30"
          }`}
        />
      ))}
    </div>
  );

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
          <Search className="w-6 h-6 text-primary" /> Find Business
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Recherchez un commerce et consultez ses avis Google
        </p>
      </div>

      {/* Search bar */}
      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && searchPlaces()}
            placeholder="Restaurant Le Petit Bistro Paris, Coiffeur Lyon..."
            className="pl-10"
          />
        </div>
        <Button variant="hero" onClick={searchPlaces} disabled={searching}>
          {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : "Rechercher"}
        </Button>
      </div>

      {/* Results */}
      {places.length > 0 && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">{places.length} résultat(s)</p>
          {places.map((place) => {
            const isExpanded = expandedPlace === place.id;
            const detail = placeDetails[place.id];
            const isLoading = loadingDetail === place.id;

            return (
              <div key={place.id} className="glass-card overflow-hidden">
                {/* Place header */}
                <button
                  onClick={() => toggleDetails(place.id)}
                  className="w-full p-5 text-left flex items-center gap-4 hover:bg-secondary/20 transition-colors"
                >
                  <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">
                      {place.displayName?.text || "Sans nom"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {place.formattedAddress}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    {place.rating && (
                      <div className="text-right">
                        <div className="flex items-center gap-1">
                          {renderStars(place.rating)}
                          <span className="text-sm font-bold ml-1">{place.rating}</span>
                        </div>
                        {place.userRatingCount && (
                          <p className="text-xs text-muted-foreground">
                            {place.userRatingCount.toLocaleString("fr-FR")} avis
                          </p>
                        )}
                      </div>
                    )}
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {/* Link button */}
                <div className="px-5 pb-3 -mt-1">
                  {linkedPlaceId === place.id ? (
                    <span className="inline-flex items-center gap-1.5 text-xs text-green-600 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Établissement lié
                    </span>
                  ) : (
                    <Button
                      variant="heroOutline"
                      size="sm"
                      disabled={linking === place.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        linkBusiness(place);
                      }}
                    >
                      {linking === place.id ? (
                        <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                      ) : (
                        <Link2 className="w-3.5 h-3.5 mr-1.5" />
                      )}
                      {linking === place.id ? "Liaison..." : "C'est mon établissement"}
                    </Button>
                  )}
                </div>

                {/* Expanded reviews */}
                {isExpanded && (
                  <div className="border-t border-border/30 p-5 space-y-4">
                    {isLoading ? (
                      <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">Chargement des avis...</span>
                      </div>
                    ) : detail?.reviews?.length ? (
                      <>
                        <div className="flex items-center justify-between">
                          <h3 className="text-sm font-semibold">
                            Derniers avis ({detail.reviews.length})
                          </h3>
                          {detail.googleMapsUri && (
                            <a
                              href={detail.googleMapsUri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-primary hover:underline flex items-center gap-1"
                            >
                              Voir sur Google Maps <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                        <div className="space-y-3">
                          {detail.reviews.map((review, idx) => (
                            <div
                              key={review.name || idx}
                              className="p-4 rounded-lg bg-secondary/30 space-y-2"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                                  {review.authorAttribution?.displayName?.charAt(0) || "?"}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium truncate">
                                    {review.authorAttribution?.displayName || "Anonyme"}
                                  </p>
                                  <div className="flex items-center gap-2">
                                    {renderStars(review.rating)}
                                    {review.relativePublishTimeDescription && (
                                      <span className="text-xs text-muted-foreground">
                                        {review.relativePublishTimeDescription}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              {review.text?.text && (
                                <p className="text-sm text-muted-foreground leading-relaxed">
                                  {review.text.text}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-6">
                        Aucun avis disponible pour cet établissement.
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Empty state */}
      {!searching && places.length === 0 && (
        <div className="glass-card p-12 text-center space-y-3">
          <Search className="w-10 h-10 text-muted-foreground/30 mx-auto" />
          <p className="text-sm text-muted-foreground">
            Recherchez un commerce par nom, adresse ou type d'activité
          </p>
        </div>
      )}
    </div>
  );
}

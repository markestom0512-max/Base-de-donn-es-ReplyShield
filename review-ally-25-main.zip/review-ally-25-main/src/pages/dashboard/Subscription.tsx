import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { PLANS, PlanSlug } from "@/lib/stripe";
import { Button } from "@/components/ui/button";
import { CreditCard, Check, ArrowUpRight, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Subscription() {
  const { subscription, refreshSubscription } = useAuth();
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [portalLoading, setPortalLoading] = useState(false);

  const handleCheckout = async (planSlug: PlanSlug) => {
    setCheckoutLoading(planSlug);
    try {
      const plan = PLANS[planSlug];
      const { data, error } = await supabase.functions.invoke("create-checkout", {
        body: { priceId: plan.price_id },
      });
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (err: any) {
      toast.error(err.message || "Erreur lors de la création du checkout");
    } finally {
      setCheckoutLoading(null);
    }
  };

  const handlePortal = async () => {
    setPortalLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (err: any) {
      toast.error(err.message || "Erreur lors de l'ouverture du portail");
    } finally {
      setPortalLoading(false);
    }
  };

  const currentPlan = subscription.plan;
  const isSubscribed = subscription.subscribed;

  return (
    <div className="space-y-6 max-w-4xl">
      <h1 className="font-heading text-2xl font-bold">Abonnement</h1>

      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-4">
          <CreditCard className="w-5 h-5 text-primary" />
          <h2 className="font-heading font-semibold">Plan actuel</h2>
        </div>
        <div className="flex items-center gap-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
          <div className="flex-1">
            {isSubscribed && currentPlan ? (
              <>
                <p className="font-heading font-bold text-lg">Plan {PLANS[currentPlan].name}</p>
                {subscription.subscriptionEnd && (
                  <p className="text-sm text-muted-foreground">
                    Prochain renouvellement : {new Date(subscription.subscriptionEnd).toLocaleDateString("fr-FR")}
                  </p>
                )}
              </>
            ) : (
              <>
                <p className="font-heading font-bold text-lg">Aucun abonnement actif</p>
                <p className="text-sm text-muted-foreground">Choisissez un plan ci-dessous pour commencer</p>
              </>
            )}
          </div>
          <span className={`text-xs px-3 py-1 rounded-full font-medium ${isSubscribed ? "bg-primary/20 text-primary" : "bg-accent/20 text-accent"}`}>
            {isSubscribed ? "Actif" : "Inactif"}
          </span>
        </div>
        <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={refreshSubscription}>
          Rafraîchir le statut
        </Button>
      </div>

      {/* Plan comparison */}
      <div className="grid md:grid-cols-3 gap-4">
        {(Object.keys(PLANS) as PlanSlug[]).map((slug) => {
          const plan = PLANS[slug];
          const isCurrent = currentPlan === slug;
          return (
            <div key={slug} className={`glass-card p-6 ${isCurrent ? "border-primary/50 ring-1 ring-primary/20" : ""}`}>
              {isCurrent && (
                <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full font-medium mb-3 inline-block">Votre plan</span>
              )}
              <h3 className="font-heading font-bold text-lg mb-1">{plan.name}</h3>
              <p className="text-2xl font-heading font-extrabold mb-4">
                {plan.price}<span className="text-sm text-muted-foreground font-normal">/mois</span>
              </p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-primary" />{f}
                  </li>
                ))}
              </ul>
              <Button
                variant={isCurrent ? "heroOutline" : "hero"}
                size="sm"
                className="w-full"
                disabled={isCurrent || checkoutLoading === slug}
                onClick={() => handleCheckout(slug)}
              >
                {checkoutLoading === slug && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
                {isCurrent ? "Plan actuel" : "Choisir ce plan"}
              </Button>
            </div>
          );
        })}
      </div>

      {isSubscribed && (
        <div className="glass-card p-6">
          <h2 className="font-heading font-semibold mb-3">Gérer mon abonnement</h2>
          <p className="text-sm text-muted-foreground mb-4">Modifiez votre plan, vos informations de paiement ou annulez votre abonnement.</p>
          <Button variant="heroOutline" size="sm" onClick={handlePortal} disabled={portalLoading}>
            {portalLoading ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <ArrowUpRight className="w-4 h-4 mr-1" />}
            Portail de facturation
          </Button>
        </div>
      )}
    </div>
  );
}

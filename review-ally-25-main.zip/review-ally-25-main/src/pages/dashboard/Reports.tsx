import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { BarChart3, Download, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { toast } from "sonner";

const COLORS = ["hsl(142, 71%, 45%)", "hsl(45, 97%, 56%)", "hsl(0, 84%, 60%)"];

export default function Reports() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ positive: 0, neutral: 0, negative: 0, total: 0, avgRating: 0 });
  const [recommendations, setRecommendations] = useState<{ titre: string; description: string }[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(false);

  useEffect(() => {
    if (user) loadStats();
  }, [user]);

  const loadStats = async () => {
    const { data: establishments } = await supabase.from("establishments").select("id").eq("user_id", user!.id);
    if (!establishments?.length) return;
    const { data: reviews } = await supabase.from("reviews").select("*").in("establishment_id", establishments.map((e) => e.id));
    if (reviews) {
      const positive = reviews.filter((r) => r.sentiment === "positive").length;
      const negative = reviews.filter((r) => r.sentiment === "negative").length;
      const neutral = reviews.filter((r) => r.sentiment === "neutral").length;
      const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
      setStats({ positive, neutral, negative, total: reviews.length, avgRating: Math.round(avgRating * 10) / 10 });
    }
  };

  const generateRecommendations = async () => {
    setLoadingRecs(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-reply", {
        body: {
          customPrompt: `Analyse ces données de réputation Google pour une entreprise :
- Note moyenne : ${stats.avgRating}/5
- Avis ce mois : ${stats.total}
- Avis positifs : ${stats.positive}, négatifs : ${stats.negative}, neutres : ${stats.neutral}
Donne 3 recommandations concrètes et actionnables pour améliorer la réputation.
Format: JSON array avec "titre" et "description" pour chaque recommandation. Réponds uniquement avec le JSON.`,
        },
      });
      if (error) throw error;
      try {
        const parsed = JSON.parse(data.reply);
        setRecommendations(Array.isArray(parsed) ? parsed : []);
      } catch {
        setRecommendations([{ titre: "Recommandation", description: data.reply }]);
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingRecs(false);
    }
  };

  const sentimentData = [
    { name: "Positifs", value: stats.positive },
    { name: "Neutres", value: stats.neutral },
    { name: "Négatifs", value: stats.negative },
  ];

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold flex items-center gap-2"><BarChart3 className="w-6 h-6 text-primary" /> Rapports</h1>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="glass-card p-5 text-center">
          <p className="text-3xl font-heading font-bold text-primary">{stats.avgRating} ⭐</p>
          <p className="text-xs text-muted-foreground mt-1">Note moyenne</p>
        </div>
        <div className="glass-card p-5 text-center">
          <p className="text-3xl font-heading font-bold">{stats.total}</p>
          <p className="text-xs text-muted-foreground mt-1">Avis totaux</p>
        </div>
        <div className="glass-card p-5 text-center">
          <p className="text-3xl font-heading font-bold text-primary">{stats.total ? Math.round((stats.positive / stats.total) * 100) : 0}%</p>
          <p className="text-xs text-muted-foreground mt-1">Positifs</p>
        </div>
      </div>

      {/* Sentiment chart */}
      {stats.total > 0 && (
        <div className="glass-card p-6">
          <h3 className="font-heading font-semibold mb-4">Répartition des sentiments</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={sentimentData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {sentimentData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* AI Recommendations */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" /> Recommandations IA</h3>
          <Button variant="hero" size="sm" onClick={generateRecommendations} disabled={loadingRecs || stats.total === 0}>
            {loadingRecs ? <RefreshCw className="w-4 h-4 animate-spin mr-1" /> : <Sparkles className="w-4 h-4 mr-1" />}
            {loadingRecs ? "Analyse..." : "Générer"}
          </Button>
        </div>
        {recommendations.length > 0 ? (
          <div className="space-y-3">
            {recommendations.map((rec, i) => (
              <div key={i} className="p-4 bg-primary/5 rounded-lg">
                <p className="font-semibold text-sm mb-1">{rec.titre}</p>
                <p className="text-xs text-muted-foreground">{rec.description}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">
            {stats.total === 0 ? "Ajoutez des avis pour obtenir des recommandations." : "Cliquez sur \"Générer\" pour obtenir des recommandations personnalisées."}
          </p>
        )}
      </div>
    </div>
  );
}

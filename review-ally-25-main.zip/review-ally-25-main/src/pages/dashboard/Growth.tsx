import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Copy, Mail, Share2, Calculator, Rocket, Lock } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";

export default function Growth() {
  const { subscription } = useAuth();
  const hasAccess = subscription.plan === "pro" || subscription.plan === "agency";

  const [emailType, setEmailType] = useState("restaurant");
  const [emailCity, setEmailCity] = useState("");
  const [generatedEmail, setGeneratedEmail] = useState<{ subject: string; body: string } | null>(null);
  const [socialType, setSocialType] = useState("linkedin");
  const [generatedSocial, setGeneratedSocial] = useState("");
  const [loading, setLoading] = useState<string | null>(null);
  const [roiReviews, setRoiReviews] = useState(20);
  const [roiMinutes, setRoiMinutes] = useState(10);
  const [roiRate, setRoiRate] = useState(30);

  if (!hasAccess) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center max-w-md mx-auto space-y-4">
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
          <Lock className="w-7 h-7 text-primary" />
        </div>
        <h1 className="font-heading text-2xl font-bold">Fonctionnalité Pro</h1>
        <p className="text-sm text-muted-foreground">
          Le Kit de Croissance est réservé aux plans <strong>Pro</strong> et <strong>Agence</strong>. Passez à un plan supérieur pour débloquer les outils marketing IA.
        </p>
        <Button variant="hero" asChild>
          <Link to="/dashboard/subscription">Voir les plans</Link>
        </Button>
      </div>
    );
  }
  const timeSaved = (roiReviews * roiMinutes) / 60;
  const moneySaved = timeSaved * roiRate;
  const roi = moneySaved > 0 ? Math.round(((moneySaved - 59) / 59) * 100) : 0;

  const generateEmail = async () => {
    if (!emailCity) { toast.error("Entrez une ville"); return; }
    setLoading("email");
    try {
      const { data, error } = await supabase.functions.invoke("generate-reply", {
        body: {
          customPrompt: `Génère un email de prospection court et percutant (max 120 mots) pour convaincre un(e) ${emailType} de ${emailCity} d'essayer ReplyShield gratuitement. Contexte: outil SaaS qui répond automatiquement aux avis Google grâce à l'IA. Bénéfice: gain de temps + meilleur référencement local. Offre: essai gratuit 14 jours, sans CB. Ton: direct, humain, pas corporate. Format JSON: { "subject": "...", "body": "..." }`,
        },
      });
      if (error) throw error;
      try {
        const parsed = JSON.parse(data.reply);
        setGeneratedEmail(parsed);
      } catch {
        setGeneratedEmail({ subject: "Email généré", body: data.reply });
      }
    } catch (err: any) {
      toast.error("Erreur: " + err.message);
    } finally {
      setLoading(null);
    }
  };

  const generateSocial = async () => {
    setLoading("social");
    try {
      const typeLabels: Record<string, string> = { linkedin: "post LinkedIn", instagram: "post Instagram", twitter: "thread Twitter/X (5 tweets)", facebook: "post Facebook" };
      const { data, error } = await supabase.functions.invoke("generate-reply", {
        body: {
          customPrompt: `Génère un ${typeLabels[socialType]} pour promouvoir ReplyShield (SaaS de gestion d'avis Google par IA). Cible: propriétaires de petites entreprises locales francophones. Ton: éducatif + légèrement décalé, pas vendeur agressif. Inclure: 1 statistique choc sur les avis Google, 1 appel à l'action vers le site. Hashtags pertinents inclus.`,
        },
      });
      if (error) throw error;
      setGeneratedSocial(data.reply);
    } catch (err: any) {
      toast.error("Erreur: " + err.message);
    } finally {
      setLoading(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copié !");
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
          <Rocket className="w-6 h-6 text-primary" /> Kit de Croissance
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Outils marketing automatisés pour développer votre base clients</p>
      </div>

      {/* Email generator */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold flex items-center gap-2"><Mail className="w-4 h-4 text-primary" /> Générateur d'emails d'acquisition</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-xs">Type d'entreprise</Label>
            <Select value={emailType} onValueChange={setEmailType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="restaurant">Restaurant</SelectItem>
                <SelectItem value="coiffeur">Coiffeur</SelectItem>
                <SelectItem value="dentiste">Dentiste</SelectItem>
                <SelectItem value="hotel">Hôtel</SelectItem>
                <SelectItem value="garage">Garage auto</SelectItem>
                <SelectItem value="boutique">Boutique</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Ville</Label>
            <Input value={emailCity} onChange={(e) => setEmailCity(e.target.value)} placeholder="Lyon, Paris..." />
          </div>
        </div>
        <Button variant="hero" size="sm" onClick={generateEmail} disabled={loading === "email"}>
          <Sparkles className="w-4 h-4 mr-1" /> {loading === "email" ? "Génération..." : "Générer l'email"}
        </Button>
        {generatedEmail && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs text-primary font-medium">Objet: {generatedEmail.subject}</p>
              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(`Objet: ${generatedEmail.subject}\n\n${generatedEmail.body}`)}><Copy className="w-3 h-3" /></Button>
            </div>
            <p className="text-sm whitespace-pre-wrap">{generatedEmail.body}</p>
          </div>
        )}
      </div>

      {/* Social media generator */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold flex items-center gap-2"><Share2 className="w-4 h-4 text-primary" /> Générateur de posts réseaux sociaux</h2>
        <div className="flex gap-2 flex-wrap">
          {[{ key: "linkedin", label: "LinkedIn" }, { key: "instagram", label: "Instagram" }, { key: "twitter", label: "Twitter/X" }, { key: "facebook", label: "Facebook" }].map((s) => (
            <button key={s.key} onClick={() => setSocialType(s.key)} className={`text-xs px-3 py-1.5 rounded-full ${socialType === s.key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>{s.label}</button>
          ))}
        </div>
        <Button variant="hero" size="sm" onClick={generateSocial} disabled={loading === "social"}>
          <Sparkles className="w-4 h-4 mr-1" /> {loading === "social" ? "Génération..." : "Générer le post"}
        </Button>
        {generatedSocial && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <div className="flex justify-end mb-2">
              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(generatedSocial)}><Copy className="w-3 h-3" /></Button>
            </div>
            <p className="text-sm whitespace-pre-wrap">{generatedSocial}</p>
          </div>
        )}
      </div>

      {/* ROI Calculator */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold flex items-center gap-2"><Calculator className="w-4 h-4 text-primary" /> Calculateur de ROI</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label className="text-xs">Avis / mois</Label>
            <Input type="number" value={roiReviews} onChange={(e) => setRoiReviews(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Minutes / réponse</Label>
            <Input type="number" value={roiMinutes} onChange={(e) => setRoiMinutes(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Tarif horaire (€)</Label>
            <Input type="number" value={roiRate} onChange={(e) => setRoiRate(Number(e.target.value))} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 pt-4">
          <div className="text-center p-4 bg-primary/5 rounded-lg">
            <p className="text-2xl font-heading font-bold text-primary">{timeSaved.toFixed(1)}h</p>
            <p className="text-xs text-muted-foreground">Temps économisé/mois</p>
          </div>
          <div className="text-center p-4 bg-primary/5 rounded-lg">
            <p className="text-2xl font-heading font-bold text-primary">{moneySaved.toFixed(0)}€</p>
            <p className="text-xs text-muted-foreground">Argent économisé/mois</p>
          </div>
          <div className="text-center p-4 bg-primary/5 rounded-lg">
            <p className="text-2xl font-heading font-bold text-primary">{roi > 0 ? `+${roi}%` : "—"}</p>
            <p className="text-xs text-muted-foreground">ROI vs abonnement Pro</p>
          </div>
        </div>
      </div>
    </div>
  );
}

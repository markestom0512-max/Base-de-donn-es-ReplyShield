import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Save, Link2, RefreshCw, CheckCircle2 } from "lucide-react";

const sectors = [
  { value: "restaurant", label: "Restaurant" },
  { value: "hotel", label: "Hôtel" },
  { value: "commerce", label: "Commerce" },
  { value: "sante", label: "Santé" },
  { value: "services", label: "Services" },
  { value: "autre", label: "Autre" },
];

export default function SettingsPage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [establishment, setEstablishment] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  const loadData = async () => {
    const { data: p } = await supabase.from("profiles").select("*").eq("id", user!.id).single();
    setProfile(p);
    const { data: e } = await supabase.from("establishments").select("*").eq("user_id", user!.id).limit(1).single();
    setEstablishment(e);
  };

  const save = async () => {
    setLoading(true);
    try {
      if (profile) await supabase.from("profiles").update(profile).eq("id", user!.id);
      if (establishment) await supabase.from("establishments").update(establishment).eq("id", establishment.id);
      toast.success("Paramètres sauvegardés !");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-8 max-w-2xl">
      <h1 className="font-heading text-2xl font-bold">Paramètres</h1>

      {/* Establishment */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold">Mon établissement</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Nom</Label>
            <Input value={establishment?.name || ""} onChange={(e) => setEstablishment({ ...establishment, name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Secteur</Label>
            <Select value={establishment?.sector || ""} onValueChange={(v) => setEstablishment({ ...establishment, sector: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{sectors.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Adresse</Label>
            <Input value={establishment?.address || ""} onChange={(e) => setEstablishment({ ...establishment, address: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Téléphone</Label>
            <Input value={establishment?.phone || ""} onChange={(e) => setEstablishment({ ...establishment, phone: e.target.value })} />
          </div>
        </div>
      </div>

      {/* Google Business */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold">Connexion Google Business</h2>
        <p className="text-sm text-muted-foreground">Entrez votre Google Place ID pour synchroniser vos avis automatiquement.</p>
        <div className="space-y-2">
          <Label className="text-xs">Google Place ID</Label>
          <Input
            value={establishment?.google_place_id || ""}
            onChange={(e) => setEstablishment({ ...establishment, google_place_id: e.target.value })}
            placeholder="ChIJ..."
          />
          <p className="text-xs text-muted-foreground">
            Trouvez votre Place ID sur{" "}
            <a href="https://developers.google.com/maps/documentation/places/web-service/place-id-finder" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
              Google Place ID Finder
            </a>
          </p>
        </div>
        {establishment?.google_place_id && (
          <Button
            variant="heroOutline"
            size="sm"
            disabled={syncing}
            onClick={async () => {
              setSyncing(true);
              try {
                // Save place ID first
                await supabase.from("establishments").update({ google_place_id: establishment.google_place_id }).eq("id", establishment.id);
                const { data, error } = await supabase.functions.invoke("sync-google-reviews", {
                  body: { establishmentId: establishment.id },
                });
                if (error) throw error;
                if (data?.error) throw new Error(data.error);
                toast.success(data.message || "Synchronisation réussie !");
                // Reload to get updated name/address
                await loadData();
              } catch (err: any) {
                toast.error(err.message || "Erreur de synchronisation");
              } finally {
                setSyncing(false);
              }
            }}
          >
            {syncing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Link2 className="w-4 h-4 mr-2" />}
            {syncing ? "Synchronisation..." : "Synchroniser les avis Google"}
          </Button>
        )}
      </div>

      {/* Tone */}
      <div className="glass-card p-6 space-y-4">
        <h2 className="font-heading font-semibold">Ton & Style IA</h2>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-muted-foreground mb-2"><span>Décontracté</span><span>Formel</span></div>
            <Slider value={[profile.tone_formal || 50]} onValueChange={(v) => setProfile({ ...profile, tone_formal: v[0] })} max={100} />
          </div>
          <div>
            <div className="flex justify-between text-xs text-muted-foreground mb-2"><span>Court</span><span>Détaillé</span></div>
            <Slider value={[profile.tone_length || 50]} onValueChange={(v) => setProfile({ ...profile, tone_length: v[0] })} max={100} />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Mots-clés à inclure</Label>
            <Input value={profile.keywords_include?.join(", ") || ""} onChange={(e) => setProfile({ ...profile, keywords_include: e.target.value.split(",").map((k: string) => k.trim()).filter(Boolean) })} />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Phrases à éviter</Label>
            <Input value={profile.keywords_avoid?.join(", ") || ""} onChange={(e) => setProfile({ ...profile, keywords_avoid: e.target.value.split(",").map((k: string) => k.trim()).filter(Boolean) })} />
          </div>
        </div>
      </div>

      {/* Auto-publish */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-heading font-semibold">Auto-publication</h2>
            <p className="text-xs text-muted-foreground">Publier les réponses automatiquement sans validation</p>
          </div>
          <Switch checked={profile.auto_publish || false} onCheckedChange={(v) => setProfile({ ...profile, auto_publish: v })} />
        </div>
      </div>

      <Button variant="hero" onClick={save} disabled={loading}>
        <Save className="w-4 h-4 mr-2" /> {loading ? "Sauvegarde..." : "Sauvegarder"}
      </Button>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Gift, Copy, Users, CheckCircle, Clock } from "lucide-react";
import { toast } from "sonner";

export default function Referral() {
  const { user } = useAuth();
  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [referrals, setReferrals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    try {
      const { data: profile } = await supabase.from("profiles").select("referral_code").eq("id", user!.id).single();
      setReferralCode(profile?.referral_code ?? null);

      const { data: refs } = await supabase.from("referrals").select("*").eq("referrer_id", user!.id).order("created_at", { ascending: false });
      setReferrals(refs ?? []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const referralLink = referralCode ? `${window.location.origin}/signup?ref=${referralCode}` : "";

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast.success("Lien copié !");
  };

  const confirmed = referrals.filter((r) => r.status === "confirmed").length;
  const pending = referrals.filter((r) => r.status === "pending").length;

  if (loading) return null;

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="font-heading text-2xl font-bold">Parrainage</h1>

      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-4">
          <Gift className="w-5 h-5 text-primary" />
          <h2 className="font-heading font-semibold">Invitez vos confrères</h2>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Partagez votre lien unique. Pour chaque inscription confirmée, vous gagnez 1 mois gratuit !
        </p>
        <div className="flex gap-2">
          <Input value={referralLink} readOnly className="font-mono text-xs" />
          <Button variant="hero" size="sm" onClick={copyLink}>
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">Confirmés</span>
          </div>
          <p className="text-2xl font-heading font-bold">{confirmed}</p>
        </div>
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-accent" />
            <span className="text-xs text-muted-foreground">En attente</span>
          </div>
          <p className="text-2xl font-heading font-bold">{pending}</p>
        </div>
      </div>

      {referrals.length > 0 && (
        <div className="glass-card p-6">
          <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
            <Users className="w-4 h-4" /> Filleuls
          </h3>
          <div className="space-y-2">
            {referrals.map((r) => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <span className="text-sm font-mono">{r.referred_id.slice(0, 8)}…</span>
                <span className={`text-xs px-2 py-1 rounded-full ${r.status === "confirmed" ? "bg-primary/20 text-primary" : "bg-accent/20 text-accent"}`}>
                  {r.status === "confirmed" ? "Confirmé" : "En attente"}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

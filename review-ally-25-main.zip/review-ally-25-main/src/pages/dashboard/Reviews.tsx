import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Star, Sparkles, RefreshCw, Check, X, Plus, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";

const SENTIMENTS: Record<string, { label: string; emoji: string }> = {
  positive: { label: "Positif", emoji: "😊" },
  neutral: { label: "Neutre", emoji: "😐" },
  negative: { label: "Négatif", emoji: "😤" },
};

const fakeReviewTemplates = [
  { author: "Marie L.", rating: 2, text: "Service décevant, j'ai attendu 45 minutes pour être servie. Le plat était froid.", sentiment: "negative" },
  { author: "Pierre D.", rating: 5, text: "Excellent ! Personnel aux petits soins, plats délicieux. On reviendra avec plaisir.", sentiment: "positive" },
  { author: "Sophie M.", rating: 4, text: "Bonne expérience globale. Cadre agréable, carte variée. Un peu bruyant en soirée.", sentiment: "positive" },
  { author: "Laurent K.", rating: 1, text: "Très déçu. Commande incorrecte, serveur désagréable quand on a signalé l'erreur.", sentiment: "negative" },
  { author: "Camille R.", rating: 3, text: "Correct sans plus. Les prix sont un peu élevés pour la qualité proposée.", sentiment: "neutral" },
  { author: "Thomas B.", rating: 5, text: "Meilleure pizza de la ville ! Pâte parfaite, ingrédients frais. Je recommande à 100%.", sentiment: "positive" },
  { author: "Isabelle F.", rating: 2, text: "Réservation non enregistrée, on a dû attendre 30 min debout. Compensation insuffisante.", sentiment: "negative" },
  { author: "Julien A.", rating: 4, text: "Très bon rapport qualité-prix. Le dessert maison est un must. Service rapide.", sentiment: "positive" },
  { author: "Nathalie V.", rating: 1, text: "Intoxication alimentaire après le repas. Inadmissible. Je ne remettrai plus les pieds ici.", sentiment: "negative" },
  { author: "François G.", rating: 5, text: "Brunch incroyable ! Tout est fait maison, le café est excellent. Personnel adorable.", sentiment: "positive" },
];

type Filter = "all" | "positive" | "negative" | "pending" | "replied";

export default function Reviews() {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<any[]>([]);
  const [filter, setFilter] = useState<Filter>("all");
  const [loading, setLoading] = useState(true);
  const [editingReply, setEditingReply] = useState<any>(null);
  const [editText, setEditText] = useState("");
  const [generating, setGenerating] = useState<string | null>(null);

  useEffect(() => {
    if (user) loadReviews();
  }, [user]);

  const loadReviews = async () => {
    setLoading(true);
    const { data: establishments } = await supabase.from("establishments").select("id").eq("user_id", user!.id);
    if (!establishments?.length) { setLoading(false); return; }
    const { data } = await supabase.from("reviews").select("*, replies(*)").in("establishment_id", establishments.map((e) => e.id)).order("created_at", { ascending: false });
    setReviews(data || []);
    setLoading(false);
  };

  const simulateReview = async () => {
    const { data: establishments } = await supabase.from("establishments").select("id").eq("user_id", user!.id);
    if (!establishments?.length) { toast.error("Aucun établissement trouvé"); return; }
    const template = fakeReviewTemplates[Math.floor(Math.random() * fakeReviewTemplates.length)];
    const { data, error } = await supabase.from("reviews").insert({
      establishment_id: establishments[0].id,
      author_name: template.author,
      rating: template.rating,
      text: template.text,
      sentiment: template.sentiment,
      published_at: new Date().toISOString(),
    }).select().single();

    if (error) { toast.error("Erreur: " + error.message); return; }
    toast.success("Avis simulé ajouté !");

    // Auto-generate reply
    if (data) {
      await generateReply(data);
    }
    loadReviews();
  };

  const generateReply = async (review: any) => {
    setGenerating(review.id);
    try {
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", user!.id).single();
      const tone = profile?.tone_formal && profile.tone_formal > 50 ? "formel" : "décontracté";
      const length = profile?.tone_length && profile.tone_length > 50 ? "détaillé" : "court";

      const { data, error } = await supabase.functions.invoke("generate-reply", {
        body: {
          reviewText: review.text,
          rating: review.rating,
          sector: profile?.sector || "commerce",
          tone: `${tone}, ${length}`,
          keywords: profile?.keywords_include || [],
          avoid: profile?.keywords_avoid || [],
        },
      });

      if (error) throw error;
      const replyText = data?.reply || "Réponse non disponible";

      // Check if reply already exists
      const existing = reviews.find((r) => r.id === review.id)?.replies?.[0];
      if (existing) {
        await supabase.from("replies").update({ generated_text: replyText, final_text: replyText, status: "pending" }).eq("id", existing.id);
      } else {
        await supabase.from("replies").insert({ review_id: review.id, generated_text: replyText, final_text: replyText, status: "pending" });
      }
      toast.success("Réponse IA générée !");
      loadReviews();
    } catch (err: any) {
      toast.error("Erreur IA: " + (err.message || "inconnue"));
    } finally {
      setGenerating(null);
    }
  };

  const publishReply = async (replyId: string) => {
    await supabase.from("replies").update({ status: "published", published_at: new Date().toISOString() }).eq("id", replyId);
    toast.success("Réponse publiée !");
    loadReviews();
  };

  const saveEditedReply = async () => {
    if (!editingReply) return;
    await supabase.from("replies").update({ final_text: editText }).eq("id", editingReply.id);
    toast.success("Réponse modifiée !");
    setEditingReply(null);
    loadReviews();
  };

  const filtered = reviews.filter((r) => {
    if (filter === "positive") return r.rating >= 4;
    if (filter === "negative") return r.rating <= 2;
    if (filter === "pending") return !r.replies?.length || r.replies.some((rep: any) => rep.status === "pending");
    if (filter === "replied") return r.replies?.some((rep: any) => rep.status === "published");
    return true;
  });

  const filters: { key: Filter; label: string }[] = [
    { key: "all", label: "Tous" },
    { key: "positive", label: "Positifs (4-5⭐)" },
    { key: "negative", label: "Négatifs (1-2⭐)" },
    { key: "pending", label: "En attente" },
    { key: "replied", label: "Répondus" },
  ];

  if (loading) return <div className="space-y-4"><Skeleton className="h-8 w-48" /><Skeleton className="h-40" /><Skeleton className="h-40" /></div>;

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="font-heading text-2xl font-bold">Avis & Réponses</h1>
        <Button variant="hero" size="sm" onClick={simulateReview}>
          <Plus className="w-4 h-4 mr-1" /> Simuler un avis
        </Button>
      </div>

      <div className="flex items-center gap-1 p-1 bg-secondary/30 rounded-lg w-fit text-xs">
        <AlertCircle className="w-3 h-3 text-accent ml-2 mr-1" />
        <span className="text-muted-foreground mr-2">Mode démo</span>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`text-xs px-3 py-1.5 rounded-full transition-colors ${
              filter === f.key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/80"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Reviews list */}
      {filtered.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <p className="text-muted-foreground mb-4">Aucun avis trouvé. Simulez votre premier avis !</p>
          <Button variant="hero" onClick={simulateReview}><Plus className="w-4 h-4 mr-1" /> Simuler un avis</Button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((review) => {
            const reply = review.replies?.[0];
            const sentimentInfo = SENTIMENTS[review.sentiment || "neutral"];
            return (
              <div key={review.id} className="glass-card p-6 space-y-4">
                {/* Review */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                    {review.author_name?.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-semibold text-sm">{review.author_name}</span>
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-3.5 h-3.5 ${i < review.rating ? "fill-star text-star" : "text-muted-foreground/30"}`} />
                        ))}
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-secondary">
                        {sentimentInfo.emoji} {sentimentInfo.label}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{review.text}</p>
                  </div>
                </div>

                {/* Reply */}
                {reply ? (
                  <div className="ml-14 bg-primary/5 border border-primary/20 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-3.5 h-3.5 text-primary" />
                      <span className="text-xs font-medium text-primary">Réponse IA</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ml-auto ${
                        reply.status === "published" ? "bg-primary/20 text-primary" : "bg-accent/20 text-accent"
                      }`}>
                        {reply.status === "published" ? "✅ Publiée" : "⏳ En attente"}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed">{reply.final_text || reply.generated_text}</p>
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" variant="ghost" className="text-xs" onClick={() => { setEditingReply(reply); setEditText(reply.final_text || reply.generated_text); }}>
                        ✏️ Modifier
                      </Button>
                      {reply.status !== "published" && (
                        <Button size="sm" variant="hero" className="text-xs" onClick={() => publishReply(reply.id)}>
                          <Check className="w-3 h-3 mr-1" /> Publier
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" className="text-xs" onClick={() => generateReply(review)} disabled={generating === review.id}>
                        <RefreshCw className={`w-3 h-3 mr-1 ${generating === review.id ? "animate-spin" : ""}`} /> Régénérer
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="ml-14">
                    <Button size="sm" variant="hero" onClick={() => generateReply(review)} disabled={generating === review.id}>
                      {generating === review.id ? (
                        <><RefreshCw className="w-4 h-4 mr-1 animate-spin" /> L'IA rédige...</>
                      ) : (
                        <><Sparkles className="w-4 h-4 mr-1" /> Générer une réponse IA</>
                      )}
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Edit dialog */}
      <Dialog open={!!editingReply} onOpenChange={() => setEditingReply(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-heading">Modifier la réponse</DialogTitle>
          </DialogHeader>
          <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} rows={6} />
          <div className="flex gap-2 justify-end">
            <Button variant="ghost" onClick={() => setEditingReply(null)}><X className="w-4 h-4 mr-1" /> Annuler</Button>
            <Button variant="hero" onClick={saveEditedReply}><Check className="w-4 h-4 mr-1" /> Valider & Sauvegarder</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

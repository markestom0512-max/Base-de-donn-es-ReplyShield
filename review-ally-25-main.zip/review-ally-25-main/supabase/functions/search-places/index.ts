import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const GOOGLE_PLACES_API_KEY = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!GOOGLE_PLACES_API_KEY) throw new Error("GOOGLE_PLACES_API_KEY is not configured");

    // Auth check
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { query, placeId } = await req.json();

    // If placeId is provided, fetch details + reviews for that place
    if (placeId) {
      const detailUrl = `https://places.googleapis.com/v1/places/${placeId}?fields=id,displayName,formattedAddress,rating,userRatingCount,reviews,types,websiteUri,googleMapsUri&languageCode=fr`;
      const detailRes = await fetch(detailUrl, {
        headers: {
          "X-Goog-Api-Key": GOOGLE_PLACES_API_KEY,
          "Content-Type": "application/json",
        },
      });

      if (!detailRes.ok) {
        const errText = await detailRes.text();
        console.error("Google Places detail error:", detailRes.status, errText);
        throw new Error(`Erreur Google Places API (${detailRes.status})`);
      }

      const detail = await detailRes.json();
      return new Response(JSON.stringify({ place: detail }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Text search for businesses
    if (!query || query.trim().length < 2) {
      return new Response(JSON.stringify({ places: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const searchUrl = "https://places.googleapis.com/v1/places:searchText";
    const searchRes = await fetch(searchUrl, {
      method: "POST",
      headers: {
        "X-Goog-Api-Key": GOOGLE_PLACES_API_KEY,
        "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.types,places.googleMapsUri",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        textQuery: query,
        languageCode: "fr",
        maxResultCount: 10,
      }),
    });

    if (!searchRes.ok) {
      const errText = await searchRes.text();
      console.error("Google Places search error:", searchRes.status, errText);
      throw new Error(`Erreur Google Places API (${searchRes.status})`);
    }

    const searchData = await searchRes.json();
    return new Response(JSON.stringify({ places: searchData.places || [] }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("search-places error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

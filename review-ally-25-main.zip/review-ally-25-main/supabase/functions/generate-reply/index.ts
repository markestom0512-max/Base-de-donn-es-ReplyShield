import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { reviewText, rating, sector, tone, keywords, avoid, customPrompt } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    let systemPrompt: string;
    let userPrompt: string;

    if (customPrompt) {
      systemPrompt = "Tu es un assistant marketing expert. Réponds directement sans introduction.";
      userPrompt = customPrompt;
    } else if (rating && rating >= 4) {
      systemPrompt = `Tu gères la réputation en ligne d'une entreprise locale du secteur ${sector || "commerce"}.
Ton de la marque : ${tone || "professionnel"}.
Génère une réponse chaleureuse, personnalisée et authentique à cet avis positif.
La réponse doit : remercier sincèrement, mentionner un détail spécifique de l'avis, inviter à revenir.
3-4 phrases maximum. Réponds directement avec la réponse, sans introduction.
${keywords?.length ? `Inclure si possible ces mots : ${keywords.join(", ")}` : ""}
${avoid?.length ? `Éviter ces expressions : ${avoid.join(", ")}` : ""}`;
      userPrompt = reviewText;
    } else {
      systemPrompt = `Tu gères la réputation en ligne d'une entreprise locale du secteur ${sector || "commerce"}.
Ton de la marque : ${tone || "professionnel"}.
Génère une réponse professionnelle et empathique à cet avis négatif.
La réponse doit : reconnaître le problème sans excuses excessives, proposer de résoudre en privé, rester constructive.
3-4 phrases. Ne jamais être défensif. Réponds directement avec la réponse.
${keywords?.length ? `Inclure si possible ces mots : ${keywords.join(", ")}` : ""}
${avoid?.length ? `Éviter ces expressions : ${avoid.join(", ")}` : ""}`;
      userPrompt = reviewText;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Limite de requêtes atteinte, réessayez dans un moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Crédits IA épuisés." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      throw new Error("AI gateway error: " + response.status);
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "Réponse non disponible";

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-reply error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

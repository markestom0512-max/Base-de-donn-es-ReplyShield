import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const GOOGLE_PLACES_API_KEY = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!GOOGLE_PLACES_API_KEY) throw new Error("GOOGLE_PLACES_API_KEY is not configured");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = claimsData.claims.sub;

    const { establishmentId } = await req.json();
    if (!establishmentId) throw new Error("establishmentId is required");

    // Get establishment and verify ownership
    const { data: establishment, error: estError } = await supabase
      .from("establishments")
      .select("id, google_place_id")
      .eq("id", establishmentId)
      .eq("user_id", userId)
      .single();

    if (estError || !establishment) {
      return new Response(JSON.stringify({ error: "Établissement non trouvé" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (!establishment.google_place_id) {
      return new Response(JSON.stringify({ error: "Aucun Place ID configuré pour cet établissement" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Fetch place details with reviews from Google Places API (New)
    const placeUrl = `https://places.googleapis.com/v1/places/${establishment.google_place_id}?fields=reviews,displayName,formattedAddress,rating&key=${GOOGLE_PLACES_API_KEY}&languageCode=fr`;

    const placeResponse = await fetch(placeUrl, {
      headers: { "X-Goog-Api-Key": GOOGLE_PLACES_API_KEY },
    });

    if (!placeResponse.ok) {
      const errText = await placeResponse.text();
      console.error("Google Places API error:", placeResponse.status, errText);
      throw new Error(`Erreur Google Places API (${placeResponse.status})`);
    }

    const placeData = await placeResponse.json();
    const googleReviews = placeData.reviews || [];

    // Upsert reviews into our database
    let imported = 0;
    for (const review of googleReviews) {
      const googleReviewId = review.name; // unique identifier from Google
      const authorName = review.authorAttribution?.displayName || "Anonyme";
      const authorAvatar = review.authorAttribution?.photoUri || null;
      const rating = review.rating || 3;
      const text = review.text?.text || "";
      const publishedAt = review.publishTime || new Date().toISOString();

      // Determine sentiment
      let sentiment = "neutral";
      if (rating >= 4) sentiment = "positive";
      else if (rating <= 2) sentiment = "negative";

      // Check if review already exists
      const { data: existing } = await supabase
        .from("reviews")
        .select("id")
        .eq("google_review_id", googleReviewId)
        .eq("establishment_id", establishmentId)
        .maybeSingle();

      if (!existing) {
        await supabase.from("reviews").insert({
          establishment_id: establishmentId,
          google_review_id: googleReviewId,
          author_name: authorName,
          author_avatar: authorAvatar,
          rating,
          text,
          sentiment,
          published_at: publishedAt,
        });
        imported++;
      }
    }

    // Update establishment name/address if available
    if (placeData.displayName?.text || placeData.formattedAddress) {
      const updates: Record<string, string> = {};
      if (placeData.displayName?.text) updates.name = placeData.displayName.text;
      if (placeData.formattedAddress) updates.address = placeData.formattedAddress;
      await supabase.from("establishments").update(updates).eq("id", establishmentId);
    }

    return new Response(
      JSON.stringify({
        success: true,
        imported,
        total: googleReviews.length,
        message: imported > 0 ? `${imported} nouvel(s) avis importé(s)` : "Aucun nouvel avis à importer",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("sync-google-reviews error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

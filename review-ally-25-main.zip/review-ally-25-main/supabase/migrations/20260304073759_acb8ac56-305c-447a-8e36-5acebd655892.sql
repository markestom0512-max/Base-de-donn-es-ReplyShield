
-- Create update_updated_at function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Profiles table
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  business_name text,
  sector text,
  tone_formal integer DEFAULT 50,
  tone_length integer DEFAULT 50,
  keywords_include text[],
  keywords_avoid text[],
  auto_publish boolean DEFAULT false,
  onboarding_completed boolean DEFAULT false,
  referral_code text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, referral_code)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    LOWER(SUBSTRING(MD5(NEW.id::text || NOW()::text) FROM 1 FOR 8))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Establishments table
CREATE TABLE public.establishments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  google_place_id text,
  address text,
  sector text,
  phone text,
  website text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.establishments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own establishments" ON public.establishments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own establishments" ON public.establishments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own establishments" ON public.establishments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own establishments" ON public.establishments FOR DELETE USING (auth.uid() = user_id);

CREATE TRIGGER update_establishments_updated_at BEFORE UPDATE ON public.establishments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Reviews table
CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid NOT NULL REFERENCES public.establishments(id) ON DELETE CASCADE,
  google_review_id text UNIQUE,
  author_name text NOT NULL,
  author_avatar text,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  text text,
  sentiment text CHECK (sentiment IN ('positive', 'neutral', 'negative')),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view reviews for own establishments" ON public.reviews FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.establishments WHERE id = reviews.establishment_id AND user_id = auth.uid()));
CREATE POLICY "Users can insert reviews for own establishments" ON public.reviews FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.establishments WHERE id = reviews.establishment_id AND user_id = auth.uid()));
CREATE POLICY "Users can update reviews for own establishments" ON public.reviews FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.establishments WHERE id = reviews.establishment_id AND user_id = auth.uid()));
CREATE POLICY "Users can delete reviews for own establishments" ON public.reviews FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.establishments WHERE id = reviews.establishment_id AND user_id = auth.uid()));

-- Replies table
CREATE TABLE public.replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id uuid NOT NULL REFERENCES public.reviews(id) ON DELETE CASCADE,
  generated_text text NOT NULL,
  final_text text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'published', 'rejected')),
  published_at timestamptz,
  tokens_used integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.replies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view replies for own reviews" ON public.replies FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.reviews r
    JOIN public.establishments e ON r.establishment_id = e.id
    WHERE r.id = replies.review_id AND e.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert replies for own reviews" ON public.replies FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.reviews r
    JOIN public.establishments e ON r.establishment_id = e.id
    WHERE r.id = replies.review_id AND e.user_id = auth.uid()
  ));
CREATE POLICY "Users can update replies for own reviews" ON public.replies FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM public.reviews r
    JOIN public.establishments e ON r.establishment_id = e.id
    WHERE r.id = replies.review_id AND e.user_id = auth.uid()
  ));

-- Subscriptions table
CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text NOT NULL DEFAULT 'solo' CHECK (plan IN ('solo', 'pro', 'agency')),
  status text NOT NULL DEFAULT 'trialing' CHECK (status IN ('trialing', 'active', 'past_due', 'canceled')),
  trial_ends_at timestamptz,
  current_period_end timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscription" ON public.subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own subscription" ON public.subscriptions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own subscription" ON public.subscriptions FOR UPDATE USING (auth.uid() = user_id);

-- Referrals table
CREATE TABLE public.referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'converted')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(referrer_id, referred_id)
);

ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own referrals" ON public.referrals FOR SELECT USING (auth.uid() = referrer_id);
CREATE POLICY "Users can insert referrals" ON public.referrals FOR INSERT WITH CHECK (auth.uid() = referred_id);

-- Stats counter table (for landing page)
CREATE TABLE public.global_stats (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  total_replies integer DEFAULT 0,
  total_businesses integer DEFAULT 0,
  avg_rating numeric(3,2) DEFAULT 0
);

INSERT INTO public.global_stats (total_replies, total_businesses, avg_rating) VALUES (2847, 156, 4.3);

-- Make global stats readable by everyone
ALTER TABLE public.global_stats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read global stats" ON public.global_stats FOR SELECT USING (true);
